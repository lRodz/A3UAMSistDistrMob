/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.springbootbasico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.List;
import java.util.Optional;
import org.springframework.http.ResponseEntity;

/**
 *
 * @author augus
 */
@SpringBootApplication
@RestController
public class SpringBootBasico {

    @Autowired
    private PessoaService pessoaService;

    public static void main(String[] args) {
        SpringApplication.run(SpringBootBasico.class, args);
    }

    // Página inicial - http://localhost:8080
    @GetMapping("/")
public String paginaInicial() {
    return "<html>"
            + "<head>"
            + "<title>Bradesco | Validação de CNPJ</title>"
            + "<style>"
            + "body { font-family: 'Segoe UI', Arial, sans-serif; margin: 0; padding: 0; background-color: #f4f4f4; }"
            + "header { background-color: #d90429; color: white; padding: 20px 0; text-align: center; box-shadow: 0 2px 6px rgba(0,0,0,0.2); }"
            + "header h1 { margin: 0; font-size: 28px; letter-spacing: 0.5px; }"
            + ".container { max-width: 800px; margin: 60px auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); text-align: center; }"
            + ".logo { display: block; margin: 0 auto 20px auto; width: 500px; }" // apenas esta linha controla o tamanho
            + ".container h2 { color: #333; font-size: 24px; margin-bottom: 20px; }"
            + ".menu { display: flex; justify-content: center; margin-top: 30px; }"
            + ".menu a { background: #d90429; color: white; padding: 15px 40px; border-radius: 8px; text-decoration: none; font-weight: bold; font-size: 18px; letter-spacing: 0.5px; transition: all 0.3s ease; }"
            + ".menu a:hover { background: #b70321; transform: scale(1.05); box-shadow: 0 4px 8px rgba(0,0,0,0.2); }"
            + ".footer { text-align: center; color: #888; font-size: 14px; margin-top: 40px; }"
            + "</style>"
            + "</head>"
            + "<body>"
            + "<header>"
            + "<h1>Bradesco | Sistema de Validação de CNPJ</h1>"
            + "</header>"
            + "<div class='container'>"
            + "<img src='https://upload.wikimedia.org/wikipedia/commons/a/a6/Banco_Bradesco_logo_%28horizontal%29.png' alt='Bradesco Logo' class='logo'/>"
            + "<h2>Verifique rapidamente a autenticidade de um CNPJ</h2>"
            + "<p>Nosso sistema conecta-se a bases de dados oficiais para garantir informações seguras e atualizadas.</p>"
            + "<div class='menu'>"
            + "<a href='/form-buscar'>🔍 Buscar CNPJ</a>"
            + "</div>"
            + "</div>"
            + "<div class='footer'>"
            + "<p>© 2025 Bradesco - Projeto Acadêmico UAM | Desenvolvido com Spring Boot + MySQL</p>"
            + "</div>"
            + "</body>"
            + "</html>";
}

    // GET - Mensagem simples
    // http://localhost:8080/ola
    @GetMapping("/ola")
    public String olaMundo() {
        return "Olá, mundo!";
    }

    // GET - Retornar JSON simples
    // http://localhost:8080/usuario
    @GetMapping("/usuario")
    public Usuario getUsuario() {
        return new Usuario("João Silva", 30, "joao@email.com");
    }

    // === CRUD OPERATIONS ===
    // CREATE - Salvar nova pessoa via JSON
    @PostMapping("/pessoas")
    public Pessoa salvarPessoa(@RequestBody Pessoa pessoa) {
        return pessoaService.save(pessoa);
    }

    // READ - Listar todas as pessoas
    @GetMapping("/pessoas")
    public List<Pessoa> listarPessoas() {
        return pessoaService.findAll();
    }

    // READ - Buscar pessoa por ID
    @GetMapping("/pessoas/{id}")
    public Optional<Pessoa> buscarPessoa(@PathVariable Long id) {
        return pessoaService.findById(id);
    }

    // UPDATE - Atualizar pessoa
    @PutMapping("/pessoas/{id}")
    public ResponseEntity<?> atualizarPessoa(@PathVariable Long id, @RequestBody Pessoa pessoaAtualizada) {
        try {
            Pessoa pessoa = pessoaService.update(id, pessoaAtualizada);
            return ResponseEntity.ok(pessoa);
        } catch (RuntimeException e) {
            return ResponseEntity.status(404).body(e.getMessage());
        } catch (Exception e) {
            return ResponseEntity.status(500).body("Erro ao atualizar pessoa: " + e.getMessage());
        }
    }

    @DeleteMapping("/pessoas/{id}")
    public ResponseEntity<?> deletarPessoa(@PathVariable Long id) {
        try {
            // Verifica se a pessoa existe antes de deletar
            if (!pessoaService.findById(id).isPresent()) {
                return ResponseEntity.status(404).body("Pessoa não encontrada com ID: " + id);
            }

            pessoaService.deleteById(id);
            return ResponseEntity.ok().body("{\"message\": \"Pessoa deletada com sucesso!\"}");
        } catch (Exception e) {
            return ResponseEntity.status(500).body("{\"error\": \"Erro ao deletar pessoa: " + e.getMessage() + "\"}");
        }
    }

    // Buscar pessoas por nome
    @GetMapping("/pessoas/buscar")
    public List<Pessoa> buscarPorNome(@RequestParam String nome) {
        return pessoaService.findByNomeContaining(nome);
    }

    // Buscar pessoas por idade maior que
    @GetMapping("/pessoas/idade-maior")
    public List<Pessoa> buscarPorIdadeMaior(@RequestParam int idade) {
        return pessoaService.findByIdadeGreaterThan(idade);
    }

    // Buscar todas as pessoas (já existe, mas vamos confirmar)
    @GetMapping("/pessoas/todas")
    public List<Pessoa> buscarTodas() {
        return pessoaService.findAll();
    }

    // POST alternativo - Mais simples
    /* @PostMapping("/pessoas-form")
    public List<Pessoa> salvarPessoaFormSimples(@RequestParam String nome, @RequestParam int idade) {
        Pessoa pessoa = new Pessoa(nome, idade);
        pessoaService.save(pessoa);
        return listarPessoas(); // Redireciona para a lista de pessoas
    }
     */
    // POST - Receber JSON e retornar resposta
    // http://localhost:8080/cumprimentar
    @PostMapping("/cumprimentar")
    public String cumprimentarJson(@RequestBody Pessoa pessoa) {
        return "Olá, " + pessoa.getNome() + "! Você tem " + pessoa.getIdade() + " anos.";
    }

    // POST - Receber do Formulário e salvar no banco
    // http://localhost:8080/cumprimentar-form
    @PostMapping("/cumprimentar-form")
    public String cumprimentarForm(@RequestParam String nome, @RequestParam Integer idade) {
        if (nome != null && idade != null) {
            Pessoa pessoa = new Pessoa(nome, idade);
            pessoaService.save(pessoa);
            return "Olá, " + nome + "! Você tem " + idade + " anos. Dados salvos no banco!";
        } else {
            return "Dados inválidos!";
        }
    }

    // http://localhost:8080/testepost
    /* @GetMapping("/testepost")
    public String testepost() {
        System.out.println("Entrei no teste");
        Pessoa pessoa = new Pessoa();
        pessoa.setNome("Teste");
        pessoa.setIdade(99);
        return cumprimentarJson(pessoa);
    }
     */
    // Formulário para testar POST - http://localhost:8080/form
    @GetMapping("/form")
    public String mostrarFormulario() {
        return "<html>"
                + "<body>"
                + "<h1>Teste de POST</h1>"
                + "<form action='/cumprimentar-form' method='post'>"
                + "Nome: <input type='text' name='nome'><br>"
                + "Idade: <input type='number' name='idade'><br>"
                + "<input type='submit' value='Enviar'>"
                + "</form>"
                + "<br>"
                + "<a href='/pessoas'>Ver todas as pessoas cadastradas</a>"
                + "</body>"
                + "</html>";
    }

    // Formulário de cadastro mais completo
    @GetMapping("/form-cadastro")
    public String mostrarFormularioCadastro() {
        return "<html>"
                + "<head><title>Cadastro de Pessoa</title>"
                + "<style>"
                + "body { font-family: Arial, sans-serif; margin: 40px; background-color: #f5f5f5; }"
                + ".container { max-width: 500px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }"
                + "h1 { color: #333; text-align: center; margin-bottom: 30px; }"
                + ".form-group { margin-bottom: 20px; }"
                + "label { display: block; margin-bottom: 5px; font-weight: bold; color: #555; }"
                + "input[type='text'], input[type='number'] { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; box-sizing: border-box; }"
                + ".btn { padding: 12px 20px; border: none; border-radius: 5px; cursor: pointer; text-decoration: none; display: inline-block; margin-right: 10px; }"
                + ".btn-primary { background: #007bff; color: white; }"
                + ".btn-secondary { background: #6c757d; color: white; }"
                + ".message { padding: 10px; margin: 10px 0; border-radius: 5px; display: none; }"
                + ".success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }"
                + ".error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }"
                + "</style>"
                + "</head>"
                + "<body>"
                + "<div class='container'>"
                + "<h1>➕ Cadastrar Nova Pessoa</h1>"
                + "<div id='message' class='message'></div>"
                + "<form id='cadastroForm'>"
                + "<div class='form-group'>"
                + "<label for='nome'>Nome:</label>"
                + "<input type='text' id='nome' name='nome' required>"
                + "</div>"
                + "<div class='form-group'>"
                + "<label for='idade'>Idade:</label>"
                + "<input type='number' id='idade' name='idade' required min='1' max='150'>"
                + "</div>"
                + "<button type='button' onclick='cadastrarPessoa()' class='btn btn-primary'>Cadastrar</button>"
                + "<a href='/lista-pessoas' class='btn btn-secondary'>Voltar para Lista</a>"
                + "<a href='/' class='btn btn-secondary'>Página Inicial</a>"
                + "</form>"
                + "</div>"
                + "<script>"
                + "function cadastrarPessoa() {"
                + "    const nome = document.getElementById('nome').value;"
                + "    const idade = document.getElementById('idade').value;"
                + "    "
                + "    if (!nome || !idade) {"
                + "        showMessage('Por favor, preencha todos os campos!', 'error');"
                + "        return;"
                + "    }"
                + "    "
                + "    fetch('/pessoas', {"
                + "        method: 'POST',"
                + "        headers: { 'Content-Type': 'application/json' },"
                + "        body: JSON.stringify({ nome: nome, idade: parseInt(idade) })"
                + "    })"
                + "    .then(response => response.json())"
                + "    .then(data => {"
                + "        showMessage('Pessoa cadastrada com sucesso! ID: ' + data.id, 'success');"
                + "        document.getElementById('cadastroForm').reset();"
                + "    })"
                + "    .catch(error => {"
                + "        showMessage('Erro ao cadastrar pessoa: ' + error, 'error');"
                + "    });"
                + "}"
                + ""
                + "function showMessage(text, type) {"
                + "    const messageDiv = document.getElementById('message');"
                + "    messageDiv.textContent = text;"
                + "    messageDiv.className = 'message ' + type;"
                + "    messageDiv.style.display = 'block';"
                + "    setTimeout(() => { messageDiv.style.display = 'none'; }, 5000);"
                + "}"
                + "</script>"
                + "</body>"
                + "</html>";
    }

    // Formulário para atualizar pessoa
    @GetMapping("/form-atualizar")
    public String mostrarFormularioAtualizar() {
        return "<html>"
                + "<body>"
                + "<h1>Atualizar Pessoa</h1>"
                + "<form action='/pessoas' method='post' id='updateForm'>"
                + "ID da Pessoa: <input type='number' name='id' id='pessoaId' required><br>"
                + "Novo Nome: <input type='text' name='nome' required><br>"
                + "Nova Idade: <input type='number' name='idade' required><br>"
                + "<input type='button' value='Atualizar' onclick='atualizarPessoa()'>"
                + "</form>"
                + "<div id='resultado'></div>"
                + "<script>"
                + "function atualizarPessoa() {"
                + "    const id = document.getElementById('pessoaId').value;"
                + "    const nome = document.getElementsByName('nome')[0].value;"
                + "    const idade = document.getElementsByName('idade')[0].value;"
                + "    "
                + "    fetch('/pessoas/' + id, {"
                + "        method: 'PUT',"
                + "        headers: { 'Content-Type': 'application/json' },"
                + "        body: JSON.stringify({ nome: nome, idade: parseInt(idade) })"
                + "    })"
                + "    .then(response => response.json())"
                + "    .then(data => {"
                + "        document.getElementById('resultado').innerHTML = "
                + "            '<p style=\"color: green;\">Pessoa atualizada com sucesso!</p>' + "
                + "            '<p>ID: ' + data.id + '</p>' + "
                + "            '<p>Nome: ' + data.nome + '</p>' + "
                + "            '<p>Idade: ' + data.idade + '</p>';"
                + "    })"
                + "    .catch(error => {"
                + "        document.getElementById('resultado').innerHTML = "
                + "            '<p style=\"color: red;\">Erro ao atualizar pessoa</p>';"
                + "    });"
                + "}"
                + "</script>"
                + "<br>"
                + "<a href='/pessoas'>Listar Pessoas</a> | "
                + "<a href='/'>Voltar</a>"
                + "</body>"
                + "</html>";
    }

    @GetMapping("/lista-pessoas")
    public String listarPessoasPagina() {
        List<Pessoa> pessoas = pessoaService.findAll();

        StringBuilder html = new StringBuilder();
        html.append("<html><head><title>Lista de Pessoas</title>")
                .append("<style>")
                .append("body { font-family: Arial, sans-serif; margin: 40px; background-color: #f5f5f5; }")
                .append(".container { max-width: 1000px; margin: 0 auto; background: white; padding: 20px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }")
                .append("h1 { color: #333; text-align: center; }")
                .append("table { width: 100%; border-collapse: collapse; margin: 20px 0; }")
                .append("th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }")
                .append("th { background-color: #007bff; color: white; }")
                .append("tr:hover { background-color: #f5f5f5; }")
                .append(".btn { padding: 8px 15px; margin: 2px; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; }")
                .append(".btn-primary { background: #007bff; color: white; }")
                .append(".btn-danger { background: #dc3545; color: white; }")
                .append(".btn-success { background: #28a745; color: white; }")
                .append(".empty { text-align: center; color: #666; padding: 20px; }")
                .append("</style></head><body>")
                .append("<div class='container'>")
                .append("<h1>📋 Lista de Pessoas Cadastradas</h1>")
                .append("<a href='/form-cadastro' class='btn btn-success'>➕ Nova Pessoa</a> ")
                .append("<a href='/' class='btn btn-primary'>🏠 Página Inicial</a><br><br>");

        if (pessoas.isEmpty()) {
            html.append("<div class='empty'>Nenhuma pessoa cadastrada no momento.</div>");
        } else {
            html.append("<table>")
                    .append("<tr><th>ID</th><th>Nome</th><th>Idade</th><th>Ações</th></tr>");

            for (Pessoa pessoa : pessoas) {
                html.append("<tr>")
                        .append("<td>").append(pessoa.getId()).append("</td>")
                        .append("<td>").append(pessoa.getNome()).append("</td>")
                        .append("<td>").append(pessoa.getIdade()).append("</td>")
                        .append("<td>")
                        .append("<a href='/form-atualizar' class='btn btn-primary'>✏️ Editar</a> ")
                        .append("<button onclick='deletarPessoa(").append(pessoa.getId()).append(")' class='btn btn-danger'>🗑️ Excluir</button>")
                        .append("</td>")
                        .append("</tr>");
            }
            html.append("</table>");
        }

        html.append("</div>")
                .append("<script>")
                .append("function deletarPessoa(id) {")
                .append("    if (confirm('Tem certeza que deseja excluir esta pessoa?')) {")
                .append("        fetch('/pessoas/' + id, { method: 'DELETE' })")
                .append("        .then(response => response.json())")
                .append("        .then(data => {")
                .append("            alert(data);")
                .append("            location.reload();")
                .append("        })")
                .append("        .catch(error => alert('Erro ao excluir pessoa: ' + error));")
                .append("    }")
                .append("}")
                .append("</script>")
                .append("</body></html>");

        return html.toString();
    }


@GetMapping("/form-buscar")
public String mostrarFormularioBusca() {
    return "<!DOCTYPE html>"
            + "<html lang='pt-BR'>"
            + "<head>"
            + "<meta charset='UTF-8'>"
            + "<meta name='viewport' content='width=device-width, initial-scale=1.0'>"
            + "<title>Bradesco | Buscar CNPJ</title>"
            + "<style>"
            + "body { font-family: 'Segoe UI', Arial, sans-serif; margin: 0; background-color: #f4f4f4; }"
            + "header { background-color: #d90429; color: white; padding: 20px 0; text-align: center; box-shadow: 0 2px 6px rgba(0,0,0,0.2); }"
            + "header h1 { margin: 0; font-size: 26px; letter-spacing: 0.5px; }"
            + ".container { max-width: 900px; margin: 50px auto; background: white; padding: 40px; border-radius: 12px; box-shadow: 0 4px 12px rgba(0,0,0,0.1); }"
            + "h2, h3 { color: #b30000; text-align: center; margin-bottom: 20px; }"
            + ".search-section { border: 1px solid #ddd; padding: 25px; margin: 25px 0; border-radius: 8px; background-color: #fafafa; }"
            + "input[type='text'], input[type='number'] { padding: 10px; margin: 8px; width: 60%; border: 1px solid #ccc; border-radius: 6px; font-size: 15px; }"
            + "input[type='submit'] { padding: 10px 25px; background: #d90429; color: white; border: none; border-radius: 6px; cursor: pointer; font-weight: bold; font-size: 15px; transition: all 0.3s ease; }"
            + "input[type='submit']:hover { background: #b70321; transform: scale(1.05); }"
            + ".btn { display: inline-block; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 6px; margin: 5px; transition: all 0.3s ease; }"
            + ".btn:hover { background: #555; transform: scale(1.05); }"
            + "iframe { width: 100%; height: 400px; border: 1px solid #ddd; border-radius: 8px; padding: 10px; background-color: #fff; }"
            + ".footer { text-align: center; color: #888; font-size: 14px; margin-top: 40px; }"
            + ".logo { display: block; margin: 0 auto 20px auto; width: 350px; }"
            + "</style>"
            + "</head>"
            + "<body>"
            + "<header>"
            + "<h1>Bradesco | Sistema de Validação de CNPJ</h1>"
            + "</header>"

            + "<div class='container'>"
            + "<img src='https://upload.wikimedia.org/wikipedia/commons/a/a6/Banco_Bradesco_logo_%28horizontal%29.png' alt='Bradesco Logo' class='logo'/>"

            + "<div class='search-section'>"
            + "    <h3>🔎 Buscar por CNPJ</h3>"
            + "    <form action='/pessoas/buscar' method='get' target='resultados'>"
            + "        <input type='text' name='nome' placeholder='Digite o CNPJ...' required>"
            + "        <input type='submit' value='Buscar'>"
            + "    </form>"
            + "</div>"

            /* + "<div class='search-section'>"
            + "    <h3>🎯 Buscar por Idade</h3>"
            + "    <form action='/pessoas/idade-maior' method='get' target='resultados'>"
            + "        <input type='number' name='idade' placeholder='Idade' min='1' required>"
            + "        <input type='submit' value='Buscar por Idade'>"
            + "    </form>"
            + "</div>" */

            /* + "<div class='search-section'>"
            + "    <h3>📊 Lista Completa</h3>"
            + "    <a href='/pessoas' target='resultados' class='btn'>Ver Todas (JSON)</a>"
            + "    <a href='/lista-pessoas' class='btn'>Ver Lista Completa</a>"
            + "</div>" */

            + "<div style='text-align: center; margin: 25px 0;'>"
            + "    <a href='/' class='btn'>🏠 Página Inicial</a>"
            // + "    <a href='/form-cadastro' class='btn'>➕ Novo Cadastro</a>"
            + "</div>"

            + "<div class='search-section'>"
            + "    <h3>📋 Resultados</h3>"
            + "    <iframe name='resultados'></iframe>"
            + "</div>"

            + "</div>"

            + "<div class='footer'>"
            + "<p>© 2025 Bradesco - Projeto Acadêmico UAM | Desenvolvido com Spring Boot + MySQL</p>"
            + "</div>"
            + "</body>"
            + "</html>";
}

    @GetMapping("/form-remover")
    public String mostrarFormularioRemover() {
        // Primeiro, vamos buscar todas as pessoas para mostrar na lista
        List<Pessoa> pessoas = pessoaService.findAll();

        StringBuilder html = new StringBuilder();
        html.append("<html>")
                .append("<head><title>Remover Pessoa</title>")
                .append("<style>")
                .append("body { font-family: Arial, sans-serif; margin: 40px; background-color: #f5f5f5; }")
                .append(".container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }")
                .append("h1 { color: #333; text-align: center; margin-bottom: 30px; }")
                .append(".pessoa-list { margin: 20px 0; }")
                .append(".pessoa-item { padding: 15px; border: 1px solid #ddd; margin: 10px 0; border-radius: 5px; display: flex; justify-content: space-between; align-items: center; }")
                .append(".pessoa-info { flex-grow: 1; }")
                .append(".btn { padding: 8px 15px; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; }")
                .append(".btn-danger { background: #dc3545; color: white; }")
                .append(".btn-secondary { background: #6c757d; color: white; }")
                .append(".empty { text-align: center; color: #666; padding: 20px; }")
                .append(".message { padding: 10px; margin: 10px 0; border-radius: 5px; display: none; }")
                .append(".success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }")
                .append(".error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }")
                .append("</style>")
                .append("</head>")
                .append("<body>")
                .append("<div class='container'>")
                .append("<h1>🗑️ Remover Pessoa</h1>")
                .append("<div id='message' class='message'></div>")
                .append("<a href='/' class='btn btn-secondary'>🏠 Página Inicial</a> ")
                .append("<a href='/lista-pessoas' class='btn btn-secondary'>📋 Lista de Pessoas</a>")
                .append("<br><br>");

        if (pessoas.isEmpty()) {
            html.append("<div class='empty'>Nenhuma pessoa cadastrada no momento.</div>");
        } else {
            html.append("<div class='pessoa-list'>");
            html.append("<h3>Pessoas Cadastradas:</h3>");

            for (Pessoa pessoa : pessoas) {
                html.append("<div class='pessoa-item'>")
                        .append("<div class='pessoa-info'>")
                        .append("<strong>ID: ").append(pessoa.getId()).append("</strong> | ")
                        .append("Nome: ").append(pessoa.getNome()).append(" | ")
                        .append("Idade: ").append(pessoa.getIdade())
                        .append("</div>")
                        .append("<button onclick='confirmarRemocao(").append(pessoa.getId()).append(", \"").append(pessoa.getNome()).append("\")' class='btn btn-danger'>🗑️ Remover</button>")
                        .append("</div>");
            }
            html.append("</div>");
        }

        html.append("</div>")
                .append("<script>")
                .append("function confirmarRemocao(id, nome) {")
                .append("    if (confirm('Tem certeza que deseja excluir a pessoa:\\n\\n' + nome + ' (ID: ' + id + ')\\n\\nEsta ação não pode ser desfeita!')) {")
                .append("        removerPessoa(id);")
                .append("    }")
                .append("}")
                .append("")
                .append("function removerPessoa(id) {")
                .append("    fetch('/pessoas/' + id, { ")
                .append("        method: 'DELETE',")
                .append("        headers: { ")
                .append("            'Content-Type': 'application/json',")
                .append("            'Accept': 'application/json'")
                .append("        }")
                .append("    })")
                .append("    .then(response => {")
                .append("        if (!response.ok) {")
                .append("            return response.json().then(error => { throw new Error(error.error || 'Erro na resposta do servidor'); });")
                .append("        }")
                .append("        return response.json();")
                .append("    })")
                .append("    .then(data => {")
                .append("        showMessage('✅ ' + data.message, 'success');")
                .append("        // Remove o item da lista visualmente após 1 segundo")
                .append("        setTimeout(() => {")
                .append("            location.reload(); // Recarrega a página para atualizar a lista")
                .append("        }, 1000);")
                .append("    })")
                .append("    .catch(error => {")
                .append("        console.error('Erro:', error);")
                .append("        showMessage('❌ ' + error.message, 'error');")
                .append("    });")
                .append("}")
                .append("")
                .append("function showMessage(text, type) {")
                .append("    const messageDiv = document.getElementById('message');")
                .append("    messageDiv.textContent = text;")
                .append("    messageDiv.className = 'message ' + type;")
                .append("    messageDiv.style.display = 'block';")
                .append("}")
                .append("</script>")
                .append("</body>")
                .append("</html>");

        return html.toString();
    }

    @GetMapping("/debug-busca")
    public String debugBusca() {
        return "<html>"
                + "<body>"
                + "<h1>Debug - Teste de JavaScript</h1>"
                + "<button id='testBtn'>Testar Botão</button>"
                + "<div id='output'></div>"
                + "<script>"
                + "document.getElementById('testBtn').addEventListener('click', function() {"
                + "    document.getElementById('output').innerHTML = '<h3 style=\"color: green;\">✅ JavaScript FUNCIONA!</h3>';"
                + "    console.log('Botão clicado - JavaScript funciona');"
                + "});"
                + "console.log('Página de debug carregada');"
                + "</script>"
                + "</body>"
                + "</html>";
    }
}
